import React from "react";

import classes from "./Header.module.css";
import logo from "../assets/logo.png";

function Header() {

  return (
    <div>
      <header className={classes.header}>
        <img src={logo} alt="Nav atrasts"></img>
        {/* <button className={classes.poga} onClick={switchTheme}>
          <SettingOutlined />
        </button> */}
      </header>
    </div>
  );
}

export default Header;
