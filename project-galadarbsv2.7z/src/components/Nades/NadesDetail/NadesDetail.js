import "./NadesDetail.css";
import { Carousel } from "antd";

import HoverVideoPlayer from "react-hover-video-player";

const NadesDetail = (props) => {
  function onChange(a, b, c) {
    console.log(a, b, c);
  }

  const contentStyle = {
    width: "64rem",
    height: "36rem",
    color: "#fff",
    lineHeight: "160px",
    textAlign: "center",
    background: "#364d79",
  };

  return (
    <div className="border">
      <div className="topinfo">
        <div className="nadeType">
          <h4 className="mainName">Type</h4>
          <span className="spans">{props.type}</span>
        </div>
        <div className="name">
          <h4 className="mainName">Name</h4>
          <span className="spans"> {props.name}</span>
        </div>
        <div className="map">
          <h4 className="mainName">Map</h4>
          <span className="spans"> {props.map}</span>
        </div>
      </div>
      <div className="videobox">
        <div className="videoTab">
          <iframe
            src={props.video}
            frameborder="0"
            scrolling="no"
            width="100%"
            height="100%"
            allowfullscreen
            class="iframeVideo"
          ></iframe>
        </div>
      </div>
      <div className = "videoDesc">
          <h3 className = "descTitle">Description</h3>

          <div className = "nadeDesc">{props.description}</div>
      </div>
    </div>
  );
};
export default NadesDetail;
