import Header from "./components/Header/Header";
import Nades from "./components/Nades/Nades";
import { SettingOutlined } from "@ant-design/icons";
import useLocalStorage from "use-local-storage";
import './App.css';

function App() {
  const defaultDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const [theme, setTheme] = useLocalStorage(
    "theme",
    defaultDark ? "dark" : "light"
  );

  const switchTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    console.log(newTheme);
  };

  return (
    <div className="app" data-theme={theme}>
      <button onClick={switchTheme}>
        <SettingOutlined />
      </button>
      <Header></Header>
      <Nades />
    </div>
  );
}

export default App;
